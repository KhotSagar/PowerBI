use h1b_visa;

-- check datatypes
describe h1b_data;

-- Count of cases
SELECT 
    COUNT(case_number) as Number_Of_cases
FROM
    h1b_data;
-- Count of employers    
SELECT 
    COUNT(distinct employer_name) as Number_of_Employer
FROM
    h1b_data;

-- Number of State
SELECT 
    COUNT(DISTINCT employer_city) as Number_of_City
FROM
    h1b_data;
    
-- check data values
SELECT 
    *
FROM
    h1b_data
LIMIT 5;

-- Null value checking
select count(*), count(
						case when case_number is null then 1 
                        end) from h1b_data;
-- Null value checking
select count(*), count(
						case when WAGE_RATE_OF_PAY_TO is null then 1 
                        end) from h1b_data;

-- Duplicate values checking
SELECT 
    case_number, COUNT(case_number)
FROM
    h1b_data
GROUP BY case_number
HAVING COUNT(case_number) > 1;



-- Convert the datatype and value of wage column.
update h1b_data 
set WAGE_RATE_OF_PAY_FROM = 
	case 
		when WAGE_RATE_OF_PAY_FROM='' then NULL
        else cast(replace(replace(WAGE_RATE_OF_PAY_FROM,'$',''),',','') as decimal(10,2))
        end;
 
 -- Converting data values and datatypes in correct foramt.
update h1b_data
set RECEIVED_DATE = str_to_date(RECEIVED_DATE,'%m/%d/%Y');

update h1b_data
set DECISION_DATE = str_to_date(DECISION_DATE,'%m/%d/%Y');

update h1b_data
set BEGIN_DATE = str_to_date(BEGIN_DATE,'%m/%d/%Y');

update h1b_data
set END_DATE = str_to_date(END_DATE,'%m/%d/%Y');



-- Which are the top employers in a certain state in a certain industry.

SELECT 
    employer_state,
    employer_city,
    soc_title,
    employer_name,
    COUNT(case_number) AS TotalCases,
    count(distinct agent_attorney_first_name) as Agent_Count
FROM
    h1b_data
GROUP BY employer_state , employer_name , soc_title, employer_city
ORDER BY TotalCases DESC
LIMIT 100;


SELECT 
    employer_state, soc_title
FROM
    h1b_data;
    
-- Are there certain types of jobs concentrated in certain geographical areas?
SELECT 
    employer_state, soc_code, COUNT(*) as CaseCount
FROM
    h1b_data
    group by employer_state, soc_code
    order by CaseCount desc;



-- Which functions seem to pay the most? Are there outliers in the salary data?
SELECT 
    job_title, MAX(wage_rate_of_pay_from) as Max_pay
FROM
    h1b_data
GROUP BY job_title
order by Max_pay desc;

SELECT 
    job_title,
    wage_rate_of_pay_from,
    COUNT(*) AS case_count
FROM
    h1b_data
WHERE
    wage_rate_of_pay_from > (SELECT 
            AVG(wage_rate_of_pay_from) + 3 * STDDEV(wage_rate_of_pay_from)
        FROM
            h1b_data)
GROUP BY job_title , wage_rate_of_pay_from
ORDER BY wage_rate_of_pay_from DESC
LIMIT 10;


SELECT 
    *
FROM
    h1b_data
LIMIT 5;
SELECT 
    job_title, soc_code, COUNT(case_status) AS case_count
FROM
    h1b_data
    group by job_title, soc_code
    order by case_count desc
    limit 10;
    
SELECT 
    agent_representing_employer,
    case_status,
    COUNT(case_status) AS case_count
FROM
    h1b_data
GROUP BY agent_representing_employer, case_status;

SELECT 
    soc_title, wage_rate_of_pay_from, count(case_number) as case_count
FROM
    h1b_data
    group by soc_title, wage_rate_of_pay_from
    order by case_count desc;
    
select distinct soc_title from h1b_data;



SELECT 
    job_title,
    Employer_name,
    COUNT(case_number) AS TotalCases,
    COUNT(DISTINCT AGENT_ATTORNEY_LAST_NAME) AS AgentCount,
    avg(WAGE_RATE_OF_PAY_FROM)
FROM
    h1b_data
GROUP BY job_title , Employer_name
ORDER BY TotalCases DESC
LIMIT 100;


SELECT 
    case_status, COUNT(case_number) AS totalCase
FROM
    h1b_data
    group by case_status;
    
    
SELECT 
    count(CASE_NUMBER) TotalCase, RECEIVED_DATE
FROM
    h1b_data
    group by RECEIVED_DATE;
    
SELECT 
    COUNT(case_number) AS case_count, job_title, EMPLOYER_STATE, EMPLOYER_COUNTRY, EMPLOYER_CITY, SOC_CODE
FROM
    h1b_data
    group by EMPLOYER_STATE, EMPLOYER_COUNTRY, EMPLOYER_CITY, SOC_CODE, job_title
    order by case_count desc;
    
    
SELECT 
    COUNT(case_number) AS Case_count, soc_title, case_status
FROM
    h1b_data
    group by soc_title, case_status
    order by Case_count desc
    limit 15;